import "dotenv/config";
import express from "express";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import session from "express-session";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const dbFile=path.join(__dirname,"data.json");
const db=fs.existsSync(dbFile)?JSON.parse(fs.readFileSync(dbFile,"utf8")):{users:[],projects:[]};
const save=()=>fs.writeFileSync(dbFile,JSON.stringify(db,null,2));
const hash=(p,s)=>crypto.scryptSync(p,s,64).toString("hex");
const newId=()=>crypto.randomBytes(16).toString("hex");
const client=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;

app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:false}));
app.use(compression());
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
app.use(express.json({limit:"2mb"}));
app.use(session({secret:process.env.SESSION_SECRET||"dev-only-change-me",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*24*60*60*1000}}));
app.use(express.static(path.join(__dirname,"public")));
app.get("/health",(req,res)=>res.json({ok:true,service:"Mfaco Studio"}));

function auth(req,res,next){if(!req.session.userId)return res.status(401).json({error:"Please log in."});next()}
function api(req,res){if(!client)return res.status(500).json({error:"Server AI key is not configured."});return true}
function addProject(userId,type,prompt,status="processing",extra={}){const p={id:newId(),userId,type,prompt,status,createdAt:new Date().toISOString(),...extra};db.projects.unshift(p);save();return p}

app.post("/api/register",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(), password=String(req.body.password||"");
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)||password.length<8)return res.status(400).json({error:"Use a valid email and a password of at least 8 characters."});
  if(db.users.some(u=>u.email===email))return res.status(409).json({error:"An account with this email already exists."});
  const salt=crypto.randomBytes(16).toString("hex");
  const user={id:newId(),email,salt,passwordHash:hash(password,salt),credits:100,createdAt:new Date().toISOString()};
  db.users.push(user);save();req.session.userId=user.id;res.json({email:user.email,credits:user.credits});
});
app.post("/api/login",(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||"");
  const u=db.users.find(x=>x.email===email);if(!u||hash(password,u.salt)!==u.passwordHash)return res.status(401).json({error:"Incorrect email or password."});
  req.session.userId=u.id;res.json({email:u.email,credits:u.credits});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>{const u=db.users.find(x=>x.id===req.session.userId);if(!u)return res.json({loggedIn:false});res.json({loggedIn:true,email:u.email,credits:u.credits})});
app.get("/api/projects",auth,(req,res)=>res.json(db.projects.filter(p=>p.userId===req.session.userId)));
app.delete("/api/projects/:id",auth,(req,res)=>{const i=db.projects.findIndex(p=>p.id===req.params.id&&p.userId===req.session.userId);if(i<0)return res.status(404).json({error:"Project not found."});db.projects.splice(i,1);save();res.json({ok:true})});

app.post("/api/story",auth,async(req,res)=>{
 try{if(!api(req,res))return;const prompt=String(req.body.prompt||"").trim();if(!prompt)return res.status(400).json({error:"Prompt required."});
 const r=await client.responses.create({model:"gpt-5.6",input:`Create an original short-form video script from this idea. Give a title, hook, 5 scenes, narration and visual directions. Idea: ${prompt}`});
 const p=addProject(req.session.userId,"story",prompt,"completed",{result:r.output_text});res.json(p);
 }catch(e){res.status(500).json({error:e.message})}
});
app.post("/api/image",auth,async(req,res)=>{
 try{if(!api(req,res))return;const prompt=String(req.body.prompt||"").trim();if(!prompt)return res.status(400).json({error:"Prompt required."});
 const r=await client.images.generate({model:"gpt-image-2",prompt,size:"1024x1024"});const b=r.data?.[0]?.b64_json;
 const p=addProject(req.session.userId,"image",prompt,"completed",{image:b});res.json(p);
 }catch(e){res.status(500).json({error:e.message})}
});
app.post("/api/voice",auth,async(req,res)=>{
 try{if(!api(req,res))return;const prompt=String(req.body.prompt||"").trim();if(!prompt)return res.status(400).json({error:"Text required."});
 const a=await client.audio.speech.create({model:"gpt-4o-mini-tts",voice:"alloy",input:prompt});
 const p=addProject(req.session.userId,"voice",prompt,"completed",{audio:Buffer.from(await a.arrayBuffer()).toString("base64"),mime:"audio/mpeg"});res.json(p);
 }catch(e){res.status(500).json({error:e.message})}
});
app.post("/api/video",auth,async(req,res)=>{
 try{if(!api(req,res))return;const prompt=String(req.body.prompt||"").trim();if(!prompt)return res.status(400).json({error:"Prompt required."});
 const v=await client.videos.create({model:"sora-2",prompt,seconds:"4",size:"720x1280"});
 const p=addProject(req.session.userId,"video",prompt,v.status||"queued",{jobId:v.id});res.json(p);
 }catch(e){res.status(500).json({error:e.message})}
});
app.get("/api/video/:id/status",auth,async(req,res)=>{
 try{if(!api(req,res))return;const v=await client.videos.retrieve(req.params.id);res.json({status:v.status})}catch(e){res.status(500).json({error:e.message})}
});
app.get("/api/video/:id/content",auth,async(req,res)=>{
 try{if(!api(req,res))return;const r=await client.videos.downloadContent(req.params.id);res.type("mp4").send(Buffer.from(await r.arrayBuffer()))}catch(e){res.status(500).json({error:e.message})}
});
app.listen(process.env.PORT||3000,()=>console.log(`Mfaco Studio: http://localhost:${process.env.PORT||3000}`));