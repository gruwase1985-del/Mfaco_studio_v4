# Mfaco Studio v4 — deployment-ready starter

This version moves the project beyond a visual demo:
- Red/black Mfaco Studio branding and logo.
- Real server-side registration/login/logout.
- Hashed passwords and sessions.
- Project history and deletion.
- Video, image, story and voice generation API routes.
- Templates.
- Dashboard.
- Security headers, compression and rate limiting.
- Health endpoint at `/health`.
- Dockerfile and Render deployment configuration.
- Privacy and Terms starter pages.

## Run locally
1. Install Node.js 22+.
2. Copy `.env.example` to `.env`.
3. Set `OPENAI_API_KEY` and a long random `SESSION_SECRET`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Important before a public launch
This package is deployment-ready but still needs your service credentials and production infrastructure. In particular:
- Put the API key only in server environment variables.
- Use a persistent database instead of the development `data.json`.
- Use object storage for generated media.
- Use a persistent session store.
- Turn on HTTPS.
- Add email verification and password reset.
- Add payment/credits if the service is paid.
- Add final privacy/terms and moderation rules.
- Connect a licensed music-generation provider for the Music feature.
- Test model availability and pricing before launch.

The current OpenAI platform supports the Responses API and current GPT-5.6 models, while Sora 2 and current image-generation models are listed on the platform pricing page. citeturn0search1turn0search0
